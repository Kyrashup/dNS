const giftProducts = {
	man: {
		nature: [
			{
				id: 22,
				name: 'Портативная колонка JBL Flip 6',
				price: 12999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/eb646e4d09e567c7b993fbfb902c4232/e6ddf064b8822e7599bee41d9247fd80869608f4ffaebc75604501c3fa5ee102.jpg.webp',
				description: 'Bluetooth, 4800 мА*ч, время работы - до 12 ч',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/983a64b9781aed20/portativnaa-kolonka-jbl-flip-6-cernyj/'
			},
			{
				id: 21,
				name: 'Портативная аудиосистема Fiero Emotion 150 FR900',
				price: 9999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/22430c2dc1e8a2b6dfa698517715e75a/fbafbd88b54c572f67b34fe00660e2b23be75e674f98df504299f67d6fa438b6.jpg.webp',
				description: '160 Вт, Bluetooth, AUX, 4000 мА*ч, время работы - до 8 ч',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/b077ca712afe3332/portativnaa-audiosistema-fiero-emotion-150-fr900-cernyj/'
			},
			{
				id: 25,
				name: 'Умная колонка Яндекс.Станция',
				price: 35999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/3f7e81bc3c725050b45463ac910f5fd3/360df2df1f130aa0094b32ba2c617e55222547e7d544171cc73d69b7f6b42626.jpg.webp',
				description: 'формат акустики-2.1, 65 Вт, беспроводной ПДУ, Bluetooth, Wi-Fi, Zigbee, питание - от сети',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/f29861f54d57ed20/umnaa-kolonka-andeksstancia-maks-cernyj/'
			},
			{
				id: 26,
				name: 'Беспроводные наушники Apple AirPods Max',
				price: 62449,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/c8411feed6c8b45d9b7d813cbafe72f9/bcfa0c6762d7ceab95f86329a3218371484b5862a90953adb2eb4f170730ab30.jpg.webp',
				description: '2020, 2.0, охватывающие, 8 Гц - 20000 Гц, 32Ω, Bluetooth, 5.0',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/24e508b439be3332/besprovodnye-nausniki-apple-airpods-max-serebristyj/'
			},
		],
		computers: [
			{
				id: 19,
				name: 'Монитор Raskat I27Q7D',
				price: 16199,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/2e079dca921baf9c040c0557970ee69f/074f36bf7cb01894e07e1eef5a1d72e3157ba4edb305834132e73c2035e0c11a.jpg.webp',
				description:
					'2560x1440@75 Гц, IPS, LED, 1000:1, 250 Кд/м², 178°/178°, DisplayPort, HDMI',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/b74283ebfc76d9cb/27-monitor-raskat-i27q7d-cernyj/'
			},
			{
				id: 11,
				name: 'Мышь проводная Nakatomi MOG-05U',
				price: 350,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/02dccf1c056d599c24d7d4d601f811a0/783286e6b9ea228fe24cdffa8d7614e3963c58c34a18b8fa8638868bcd449173.jpg.webp',
				description: '1600 dpi, USB Type-A, кнопки - 4 ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/949f9512e868fa76/mys-provodnaa-nakatomi-mog-05u--belyj/'
			},

			{
				id: 12,
				name: 'Клавиатура беспроводная Smartbuy SBK-206AG-K',
				price: 1050,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/b50d1405cc5fc456151d1183c4d04ea1/f3439cabd8712f9d2fa6b3c70326915f8fefeb49d415a2d55df2e863fe416d4b.jpg.webp',
				description: 'мембранная, клавиш - 104, радиоканал, черный ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/12954b77e8c03332/klaviatura-besprovodnaa-smartbuy-sbk-206ag-k/'
			},
			{
				id: 13,
				name: 'Клавиатура проводная Smartbuy SBK-333U-WK',
				price: 799,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/0/0/bf339d61e6df0396813a2c1bac3cae25/32449223a2ea0441d276f5f035aa204dd8a2eed99806d2d06ead5f885964e388.jpg.webp',
				description: 'мембранная, клавиш - 104, USB Type-A, белый ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/4f854c7e37053330/klaviatura-provodnaa-smartbuy-sbk-333u-wk/'
			},
			{
				id: 16,
				name: 'Монитор DEXP DF24N1T',
				price: 8399,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/500/500/bec830896fa2a61a4cb7be6e8e51e0f9/bbddf6dda9e0e45866aa5078ffa12d2a7961eca5a3f5131abf6f0fcbb93b3aee.jpg.webp',
				description:
					'1920x1080@100 Гц, IPS, LED, 1000:1, 250 Кд/м², 178°/178°, DisplayPort 1.4, HDMI 1.4, USB Type-C, VGA (D-Sub)',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/e555a002da91ed20/238-monitor-dexp-df24n1t-cernyj/'
			},
			{
				id: 17,
				name: 'Монитор Sanc M2453DH',
				price: 9499,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/a2227f2896f1a66417194724f34fa2e8/f69e52c785c2ce2ae5c6bfe3471cf8f94116982026b0ab56d80b17f12dd037ea.png.webp',
				description:
					'1920x1080@75 Гц, IPS, LED, 5 мс, 4000:1, 250 Кд/м², 178°/178°, HDMI, VGA (D-Sub)',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/fd3e1692488cd582/238-monitor-sanc-m2453dh-cernyj/'
			},
			{
				id: 18,
				name: 'Монитор Acer EK221QHbi',
				price: 9999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/266b2f21f5c94232ca1511cc3aa0d103/1e404a79c656e1d34223017214aa00ada0bb0624a19607a1026ebabbb4d0fbbf.jpg.webp',
				description:
					'1920x1080@100 Гц, VA, LED, 5 мс, 3000:1, 250 Кд/м², 178°/178°, HDMI 1.4, VGA (D-Sub), AMD FreeSync',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/429751d8f2e8d9cb/215-monitor-acer-ek221qhbi-cernyj/'
			},
			{
				id: 20,
				name: 'Монитор Titan Army C30SK PRO',
				price: 19999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/bb59f1500b34900c8dd069e23090d394/49dcb712f6a8520adf68e5d0d807eedcb33b19eb048c3cf7ff76128c43abbd73.jpg.webp',
				description:
					'2560x1080@200 Гц, VA, LED, 3000:1, 250 Кд/м², 178°/178°, DisplayPort 1.2 x2, HDMI 1.4 x2: 1500R, Adaptive-Sync',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/7afc9c34af5eed20/30-monitor-titan-army-c30sk-pro-cernyj/'
			},
		],
		innovation: [
			{
				id: 10,
				name: 'Смартфон Apple iPhone 15 Pro',
				price: 135999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/e853c72719633e353b65193e301cc9e9/8517b5d57caefeef97194196729bd221e1606cafc9a005f423b21eb56314ba96.jpg.webp',
				description:
					'Ядер - 6x(3.78 ГГц), 8 ГБ, 2 SIM, Super Retina XDR, 2556x1179, камера 48+12+12 Мп, NFC, 5G, GPS, 3274 мА*ч',
				category: 'Смартфоны',
				link: 'https://www.dns-shop.ru/product/8750c75a52aeed20/61-smartfon-apple-iphone-15-pro-256-gb-seryj/'
			},
			{
				id: 6,
				name: 'Смартфон OPPO A55',
				price: 8499,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/300/300/1f2f92c9b566e87ba68e88cac1bf0fd8/32b3fe074867f6536e6fe71fef7dff8a7835fb3547cb0b6aa58dc6c22d84ff56.jpg.webp',
				description:
					'Смартфон OPPO A55 128 ГБ предлагает высокую производительность, безрамочный дисплей 6.51 дюйма IPS с разрешением 1600x720 пикселей',
				category: 'Смартфоны',
				link: 'https://www.dns-shop.ru/product/a873f9a13c3fed20/651-smartfon-oppo-a55-128-gb-cernyj/'
			},
			{
				id: 7,
				name: 'Смартфон POCO C61',
				price: 6799,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/300/300/918540197d43a3027820e35e10904d9f/8b75c9f197fd3b3b6e70a23f3afe1299396d2d1a3e4e2ee696865f1650044bc4.jpg',
				description:
					'64 ГБ белого цвета предлагает дисплей 6.78,8-ядерный процессор мгновенно выполняет любые задачи',
				category: 'Смартфоны',
				link: 'https://www.dns-shop.ru/product/c32df49868edd21a/678-smartfon-poco-c61-64-gb-cernyj/'
			},
			{
				id: 8,
				name: 'Смартфон Xiaomi Redmi 14C',
				price: 13999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/300/300/aaf7d3f8297bf7b86941a33f084b5ee2/bbeb49edf51fe4d70f40a1f43fcc513fcac1b67f474b8e2f817dea82b18ee722.jpg.webp',
				description:
					'ядер - 8x(2 ГГц), 8 ГБ, 2 SIM, IPS, 1640x720, камера 50+0.08 Мп, NFC, 4G, GPS, 5160 мА*ч',
				category: 'Смартфоны',
				link: 'https://www.dns-shop.ru/product/7751ce3a6a93d0a4/688-smartfon-xiaomi-redmi-14c-256-gb-cernyj/'
			},
			{
				id: 9,
				name: 'Смартфон Samsung Galaxy S24 Ultra',
				price: 129999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/fb35114e9279b757858774c93da8ba01/4e5ef1c42dc15b2638ffdb975a81068b3c482b7fb317aae6e99307ad3570329c.jpg.webp',
				description:
					'ядер - 8x(3.39 ГГц), 12 ГБ, 2 SIM, Dynamic AMOLED 2X, 3120x1440, камера 200+50+12+10 Мп, NFC, 5G, GPS, 5000 мА*ч',
				category: 'Смартфоны',
				link: 'https://www.dns-shop.ru/product/3a8f3ef3fa6e6bba/68-smartfon-samsung-galaxy-s24-ultra-512-gb-cernyj/'
			},
		],
	},
	woman: {
		nature: [
			{
				id: 22,
				name: 'Портативная колонка JBL Flip 6',
				price: 12999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/eb646e4d09e567c7b993fbfb902c4232/e6ddf064b8822e7599bee41d9247fd80869608f4ffaebc75604501c3fa5ee102.jpg.webp',
				description: 'Bluetooth, 4800 мА*ч, время работы - до 12 ч',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/983a64b9781aed20/portativnaa-kolonka-jbl-flip-6-cernyj/'
			},
			{
				id: 21,
				name: 'Портативная аудиосистема Fiero Emotion 150 FR900',
				price: 9999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/22430c2dc1e8a2b6dfa698517715e75a/fbafbd88b54c572f67b34fe00660e2b23be75e674f98df504299f67d6fa438b6.jpg.webp',
				description: '160 Вт, Bluetooth, AUX, 4000 мА*ч, время работы - до 8 ч',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/b077ca712afe3332/portativnaa-audiosistema-fiero-emotion-150-fr900-cernyj/'
			},
			{
				id: 25,
				name: 'Умная колонка Яндекс.Станция',
				price: 35999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/3f7e81bc3c725050b45463ac910f5fd3/360df2df1f130aa0094b32ba2c617e55222547e7d544171cc73d69b7f6b42626.jpg.webp',
				description: 'формат акустики-2.1, 65 Вт, беспроводной ПДУ, Bluetooth, Wi-Fi, Zigbee, питание - от сети',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/f29861f54d57ed20/umnaa-kolonka-andeksstancia-maks-cernyj/'
			},
			{
				id: 26,
				name: 'Беспроводные наушники Apple AirPods Max',
				price: 62449,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/c8411feed6c8b45d9b7d813cbafe72f9/bcfa0c6762d7ceab95f86329a3218371484b5862a90953adb2eb4f170730ab30.jpg.webp',
				description: '2020, 2.0, охватывающие, 8 Гц - 20000 Гц, 32Ω, Bluetooth, 5.0',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/24e508b439be3332/besprovodnye-nausniki-apple-airpods-max-serebristyj/'
			},
		],
		computers: [
			{
				id: 15,
				name: 'Рюкзак для ноутбука Aceline Pol-LG-36 ',
				price: 850,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/dfabd752b79d98103903d7d803fb13c7/84881389d4dbbac8172072954263041da527bcf150bd8de9199409d999f8d3c7.jpg.webp',
				description:
					'Рюкзак Aceline Pol-LG-36 позволяет комфортно транспортировать ноутбук с диагональю экрана до 15.6 дюйма и личные вещи. ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/4522d917ae6ced20/156-rukzak-aceline-pol-lg-36-seryj/'
			},
			{
				id: 24,
				name: 'Беспроводные/проводные наушники ARDOR GAMING Vault',
				price: 5599,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/e99a12fbef73da6318cd8ebfd38d4bff/f78f4f33e6e8296cb00011bfc0c4d15d60fcb21cedd5c5320baf9ee5e4b92fb5.jpg.webp',
				description:
					'2023, 7.1 Virtual, охватывающие, 20 Гц - 20000 Гц, 64Ω, Bluetooth, проводной, радиоканал, 5.2, кабель - 1.8 м',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/676a2f27c7c3ed20/besprovodnyeprovodnye-nausniki-ardor-gaming-vault-cernyj/'
			},
			{
				id: 25,
				name: 'Проводные наушники Apple EarPods (3.5 mm) ',
				price: 2699,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/6c94f581c714b4334680dd8c02fb4b9c/79282ef0ed5db5127fad3e7204566d2a3b354fc5192c85122a971d314e35617b.jpg.webp',
				description:
					'2.0, вкладыши, 20 Гц - 20000 Гц, 16Ω, проводной, кабель - 1.2 м ',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/da74bee90e9d3330/provodnye-nausniki-apple-earpods-35-mm-belyj/'
			},
		],
		innovation: [
			{
				id: 2,
				name: 'Ноутбук HUAWEI MateBook D 16 2024 MCLF-X',
				price: 54999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/0/0/901f1eb6db5bdd92d541738298f66530/f8c1d514292bd887b7279a1fa5f26692c8c70e6dd1ca86b6a8a7b3a4f4b6b0bd.jpg.webp',
				description:
					'Ноутбук HUAWEI MateBook D 16 2024 MCLF-X диагональю 16 идет без ОС. Это позволяет подобрать систему, удобную для офисной работы или игр. В основе экрана лежит IPS-матрица с разрешением 1920x1200. ',
				category: 'Ноутбуки',
				link: 'https://www.dns-shop.ru/product/12c02b819b19ed20/16-noutbuk-huawei-matebook-d-16-2024-mclf-x-seryj/'
			},
			{
				id: 3,
				name: 'Ноутбук DEXP Aquilon C15-I5W302',
				price: 29999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/0/0/ae127c4307933167bd56b35958743bef/3ff695645d9df93d977eb177a44630fd614edfb458589ee2df2c46560cb26f0b.jpg.webp',
				description:
					'Ноутбук DEXP Aquilon синего цвета оснащен процессором Intel Core i5-1035G1 с четырьмя ядрами и тактовой частотой 1 ГГц. Компьютер справляется с многозадачностью и ресурсоемкими приложениями. ',
				category: 'Ноутбуки',
				link: 'https://www.dns-shop.ru/product/ad19e2753fd8ed20/156-noutbuk-dexp-aquilon-c15-i5w302-sinij/'
			},
			{
				id: 4,
				name: 'Ноутбук Chuwi GemiBook PLUS',
				price: 31299,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/fc5977ade2a236c1b060ea7cf4f53150/319b02f5d3ea2f886bae1397764686cfb45626f17f5cfedf30ce54dee050e332.jpg.webp',
				description:
					'английская/русская раскладка, 1920x1080, IPS, Intel Processor N100, 4 + 3.4 ГГц, RAM 16 ГБ, SSD 512 ГБ, Intel UHD Graphics, Windows 11 Home Single Language',
				category: 'Ноутбуки',
				link: 'https://www.dns-shop.ru/product/01116350e862216a/156-noutbuk-chuwi-gemibook-plus-seryj/'
			},
			{
				id: 5,
				name: 'Ноутбук HONOR MagicBook 14 NMH-WFQ9HN',
				price: 49999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/0/0/bf4a3733f929e44c89e454f0eb353efa/7be8f93f0ff42ef0b0b0cee44c7209b821782fd5dce273b933f483aaffe962e7.jpg.webp',
				description:
					'английская/русская раскладка, 1920x1080, IPS, AMD Ryzen 5 5500U, ядра: 6 х 2.1 ГГц, RAM 16 ГБ, SSD 512 ГБ, AMD Radeon Graphics, без ОС ',
				category: 'Ноутбуки',
				link: 'https://www.dns-shop.ru/product/5b951615220ced20/14-noutbuk-honor-magicbook-14-nmh-wfq9hn-seryj/'
			},
		],
	},
	child: {
		nature: [
			{
				id: 24,
				name: 'Беспроводные/проводные наушники ARDOR GAMING Vault',
				price: 5599,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/wm/0/0/e99a12fbef73da6318cd8ebfd38d4bff/f78f4f33e6e8296cb00011bfc0c4d15d60fcb21cedd5c5320baf9ee5e4b92fb5.jpg.webp',
				description:
					'2023, 7.1 Virtual, охватывающие, 20 Гц - 20000 Гц, 64Ω, Bluetooth, проводной, радиоканал, 5.2, кабель - 1.8 м',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/676a2f27c7c3ed20/besprovodnyeprovodnye-nausniki-ardor-gaming-vault-cernyj/'
			},
			{
				id: 25,
				name: 'Проводные наушники Apple EarPods (3.5 mm) ',
				price: 2699,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/6c94f581c714b4334680dd8c02fb4b9c/79282ef0ed5db5127fad3e7204566d2a3b354fc5192c85122a971d314e35617b.jpg.webp',
				description:
					'2.0, вкладыши, 20 Гц - 20000 Гц, 16Ω, проводной, кабель - 1.2 м ',
				category: 'Аудио',
				link: 'https://www.dns-shop.ru/product/da74bee90e9d3330/provodnye-nausniki-apple-earpods-35-mm-belyj/'
			},
		],
		computers: [
			{
				id: 16,
				name: 'Монитор DEXP DF24N1T',
				price: 8399,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/500/500/bec830896fa2a61a4cb7be6e8e51e0f9/bbddf6dda9e0e45866aa5078ffa12d2a7961eca5a3f5131abf6f0fcbb93b3aee.jpg.webp',
				description:
					'1920x1080@100 Гц, IPS, LED, 1000:1, 250 Кд/м², 178°/178°, DisplayPort 1.4, HDMI 1.4, USB Type-C, VGA (D-Sub)',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/e555a002da91ed20/238-monitor-dexp-df24n1t-cernyj/'
			},
			{
				id: 17,
				name: 'Монитор Sanc M2453DH',
				price: 9499,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/a2227f2896f1a66417194724f34fa2e8/f69e52c785c2ce2ae5c6bfe3471cf8f94116982026b0ab56d80b17f12dd037ea.png.webp',
				description:
					'1920x1080@75 Гц, IPS, LED, 5 мс, 4000:1, 250 Кд/м², 178°/178°, HDMI, VGA (D-Sub)',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/fd3e1692488cd582/238-monitor-sanc-m2453dh-cernyj/'
			},
			{
				id: 18,
				name: 'Монитор Acer EK221QHbi',
				price: 9999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/266b2f21f5c94232ca1511cc3aa0d103/1e404a79c656e1d34223017214aa00ada0bb0624a19607a1026ebabbb4d0fbbf.jpg.webp',
				description:
					'1920x1080@100 Гц, VA, LED, 5 мс, 3000:1, 250 Кд/м², 178°/178°, HDMI 1.4, VGA (D-Sub), AMD FreeSync',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/429751d8f2e8d9cb/215-monitor-acer-ek221qhbi-cernyj/'
			},
			{
				id: 19,
				name: 'Монитор Raskat I27Q7D',
				price: 16199,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/2e079dca921baf9c040c0557970ee69f/074f36bf7cb01894e07e1eef5a1d72e3157ba4edb305834132e73c2035e0c11a.jpg.webp',
				description:
					'2560x1440@75 Гц, IPS, LED, 1000:1, 250 Кд/м², 178°/178°, DisplayPort, HDMI',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/b74283ebfc76d9cb/27-monitor-raskat-i27q7d-cernyj/'
			},
			{
				id: 20,
				name: 'Монитор Titan Army C30SK PRO',
				price: 19999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/500/500/bb59f1500b34900c8dd069e23090d394/49dcb712f6a8520adf68e5d0d807eedcb33b19eb048c3cf7ff76128c43abbd73.jpg.webp',
				description:
					'2560x1080@200 Гц, VA, LED, 3000:1, 250 Кд/м², 178°/178°, DisplayPort 1.2 x2, HDMI 1.4 x2: 1500R, Adaptive-Sync',
				category: 'Мониторы',
				link: 'https://www.dns-shop.ru/product/7afc9c34af5eed20/30-monitor-titan-army-c30sk-pro-cernyj/'
			},
		],
		innovation: [
			{
				id: 11,
				name: 'Мышь проводная Nakatomi MOG-05U',
				price: 350,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/02dccf1c056d599c24d7d4d601f811a0/783286e6b9ea228fe24cdffa8d7614e3963c58c34a18b8fa8638868bcd449173.jpg.webp',
				description: '1600 dpi, USB Type-A, кнопки - 4 ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/949f9512e868fa76/mys-provodnaa-nakatomi-mog-05u--belyj/'
			},
			{
				id: 12,
				name: 'Клавиатура беспроводная Smartbuy SBK-206AG-K',
				price: 1050,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/b50d1405cc5fc456151d1183c4d04ea1/f3439cabd8712f9d2fa6b3c70326915f8fefeb49d415a2d55df2e863fe416d4b.jpg.webp',
				description: 'мембранная, клавиш - 104, радиоканал, черный ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/12954b77e8c03332/klaviatura-besprovodnaa-smartbuy-sbk-206ag-k/'
			},
			{
				id: 13,
				name: 'Клавиатура проводная Smartbuy SBK-333U-WK',
				price: 799,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/0/0/bf339d61e6df0396813a2c1bac3cae25/32449223a2ea0441d276f5f035aa204dd8a2eed99806d2d06ead5f885964e388.jpg.webp',
				description: 'мембранная, клавиш - 104, USB Type-A, белый ',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/4f854c7e37053330/klaviatura-provodnaa-smartbuy-sbk-333u-wk/'
			},
			{
				id: 28,
				name: 'Мышь проводная Razer DeathAdder V3',
				price: 8339,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st1/fit/wm/0/0/12cbff7db2f2039b47c0704e726c7998/ac742cb8759e14948b0a7bbe46f0a3edeeb4f8a17d7ff2b72d9b6bd02e757121.jpg.webp',
				description: '30000 dpi, USB Type-A, кнопки - 6',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/56ef38b1f514ed20/mys-provodnaa-razer-deathadder-v3-rz01-04640100-r3m1-cernyj/?utm_referrer=https%3A%2F%2Fwww.dns-shop.ru%2Fcatalog%2F17a8a69116404e77%2Fmyshi%2F%3Fq%3D%25D0%25BC%25D1%258B%25D1%2588%25D0%25BA%25D0%25B0%2B%25D0%25B8%25D0%25B3%25D1%2580%25D0%25BE%25D0%25B2%25D0%25B0%25D1%258F%26order%3D6%26stock%3Dnow-today-tomorrow-later-out_of_stock'
			},

			{
				id: 29,
				name: 'Клавиатура проводная Razer Ornata V3',
				price: 6999,
				imageUrl:
					'https://c.dns-shop.ru/thumb/st4/fit/0/0/63bf799b76c514b909c61384af7e5c15/5a5e06f31f5ce1ef16fc5a7df8deb07339773e10690c04df2c9c11e6c05927d2.jpg.webp',
				description: 'ембранная (частично механика), клавиш - 108, USB Type-A, черный',
				category: 'Компьютерные аксессуары',
				link: 'https://www.dns-shop.ru/product/08c1b0883889ed20/klaviatura-provodnaa-razer-ornata-v3-rz03-04460800-r3r1/'
			},
		],
	},
};

let cart = [];

// Обработчик формы
document.getElementById('surveyForm').addEventListener('submit', function (e) {
	e.preventDefault();

	const gender = document.getElementById('gender').value;
	const interest = document.getElementById('interest').value;
	const priceText = document.getElementById('priceLabel').textContent;

	if (!gender || !interest) {
		alert('Пожалуйста, выберите пол и интерес!');
		return;
	}

	const products = giftProducts[gender] && giftProducts[gender][interest];

	if (!products || products.length === 0) {
		alert('Товары для выбранных параметров не найдены!');
		return;
	}

	const filteredProducts = filterProductsByPrice(products, priceText);
	displayProducts(filteredProducts);
});


function updatePriceRange() {
	const minPriceInput = document.getElementById('minPriceInput');
	const maxPriceInput = document.getElementById('maxPriceInput');
	const priceLabel = document.getElementById('priceLabel');

	const minPrice = parseInt(minPriceInput.value);
	const maxPrice = parseInt(maxPriceInput.value);

	let priceText;

	if (isNaN(minPrice) || isNaN(maxPrice) || minPrice < 0 || maxPrice > 1500000 || minPrice > maxPrice) {
		priceText = 'Invalid price range';
	} else {
		priceText = `${minPrice} - ${maxPrice}`;
	}

	priceLabel.textContent = priceText;
}

function filterProductsByPrice(products, priceText) {
	const [minPrice, maxPrice] = priceText.split('-').map(Number);

	return products.filter(product => {
		return product.price >= minPrice && product.price <= maxPrice;
	});
}

// Отображение товаров
function displayProducts(products) {
	const productList = document.getElementById('productList');
	productList.innerHTML = '';

	products.forEach(product => {
		const productHTML = `
				<div class="product">
					<img src="${product.imageUrl}" alt="${product.name}">
					<h3>${product.name}</h3>
					<div class="price">${product.price} ₽</div>
					<button class="viewButton" data-id="${product.id}">Подробнее</button>
				</div>
			`;
		productList.innerHTML += productHTML;
		productHeader.style.display = "block";
	});

	// Добавляем обработчики для кнопок "Подробнее"
	document.querySelectorAll('.viewButton').forEach(button => {
		button.addEventListener('click', () => {
			const productId = parseInt(button.getAttribute('data-id'));
			showProductModal(productId);
		});
	});
}

// Показ модального окна товара
function showProductModal(productId) {
	const product = findProductById(productId);
	if (product) {
		document.getElementById('modalImage').src = product.imageUrl;
		document.getElementById('modalName').textContent = product.name;
		document.getElementById('modalPrice').textContent = `${product.price} ₽`;
		document.getElementById('modalDescription').textContent = product.description;
		document.getElementById('myModal').style.display = 'block';

		// Добавление товара в корзину
		document.getElementById('addToCartButton').onclick = () => {
			addToCart(product);
		};
	}
}

// Поиск товара по ID
function findProductById(productId) {
	for (const gender in giftProducts) {
		for (const category in giftProducts[gender]) {
			const product = giftProducts[gender][category].find(item => item.id === productId);
			if (product) {
				return product;
			}
		}
	}
	return null;
}

// Добавление товара в корзину
function addToCart(product) {
	const existingProduct = cart.find(item => item.id === product.id);
	if (existingProduct) {
		existingProduct.quantity++;
	} else {
		cart.push({ ...product, quantity: 1 });
	}
	updateCart();
	document.getElementById('myModal').style.display = 'none'; // Закрываем модальное окно товара
}

// Обновление корзины
function updateCart() {
	const cartItemsDiv = document.getElementById('cartItems');
	cartItemsDiv.innerHTML = '';
	let total = 0;

	cart.forEach(item => {
		const itemDiv = document.createElement('div');
		itemDiv.classList.add('cart-item');

		const itemImage = document.createElement('img');
		itemImage.src = item.imageUrl;
		itemImage.alt = item.name;
		itemImage.classList.add('cart-item-image');

		const itemDetails = document.createElement('div');
		itemDetails.classList.add('cart-item-details');

		const itemName = document.createElement('h3');
		itemName.textContent = item.name;

		const itemQuantity = document.createElement('div');
		itemQuantity.textContent = `Количество: ${item.quantity} шт.`;

		const itemPrice = document.createElement('div');
		itemPrice.textContent = `Цена: ${item.price} ₽`;

		const buyButton = document.createElement('a');
		buyButton.href = item.link; // Ссылка из массива
		buyButton.target = '_blank'; // Открываем в новой вкладке
		buyButton.textContent = 'Купить';
		buyButton.classList.add('buy-button');

		itemDetails.appendChild(itemName);
		itemDetails.appendChild(itemQuantity);
		itemDetails.appendChild(itemPrice);
		itemDetails.appendChild(buyButton); // Добавляем кнопку в детали

		itemDiv.appendChild(itemImage);
		itemDiv.appendChild(itemDetails);
		cartItemsDiv.appendChild(itemDiv);

		total += item.price * item.quantity;
	});

	document.getElementById('totalPrice').textContent = `Итого: ${total} ₽`;
}

// Открытие модального окна корзины
document.getElementById('cartButton').addEventListener('click', () => {
	updateCart();
	document.getElementById('cartModal').style.display = 'block';
});

// Очистка корзины
document.getElementById('clearCartButton').addEventListener('click', () => {
	cart = [];
	updateCart();
});

// Закрытие модальных окон
document.querySelectorAll('.close').forEach(closeBtn => {
	closeBtn.onclick = function () {
		const modal = this.closest('.modal');
		modal.style.display = 'none';
	};
});

// Закрытие модального окна при клике вне его
window.onclick = function (event) {
	const modals = [document.getElementById('myModal'), document.getElementById('cartModal')];
	modals.forEach(modal => {
		if (event.target == modal) {
			modal.style.display = 'none';
		}
	});
};


document.getElementById('randomGiftButton').addEventListener('click', () => {
    const gender = document.getElementById('gender').value;
    const interest = document.getElementById('interest').value;

    // Получение всех доступных товаров по текущим параметрам
    let products = [];
    if (gender && interest) {
        products = giftProducts[gender][interest] || [];
    } else {
        // Если параметры не выбраны, собрать все товары
        for (const g in giftProducts) {
            for (const i in giftProducts[g]) {
                products = products.concat(giftProducts[g][i]);
            }
        }
    }

    if (products.length === 0) {
        alert('Нет доступных товаров для случайного выбора.');
        return;
    }

    // Выбор случайного товара
    const randomProduct = products[Math.floor(Math.random() * products.length)];
    showProductModal(randomProduct.id); // Используем существующую функцию для отображения модального окна
});

document.getElementById('sortOptions').addEventListener('change', () => {
    const sortOption = document.getElementById('sortOptions').value;
    const productList = document.getElementById('productList');
    const products = Array.from(productList.children); // Получаем массив текущих товаров

    products.sort((a, b) => {
        const priceA = parseFloat(a.querySelector('.price').textContent.replace(' ₽', ''));
        const priceB = parseFloat(b.querySelector('.price').textContent.replace(' ₽', ''));
        const nameA = a.querySelector('h3').textContent.toLowerCase();
        const nameB = b.querySelector('h3').textContent.toLowerCase();

        switch (sortOption) {
            case 'priceAsc':
                return priceA - priceB;
            case 'priceDesc':
                return priceB - priceA;
            case 'nameAsc':
                return nameA.localeCompare(nameB);
            case 'nameDesc':
                return nameB.localeCompare(nameA);
            default:
                return 0; // Без изменений
        }
    });

    // Очистка списка и добавление отсортированных товаров
    productList.innerHTML = '';
    products.forEach(product => productList.appendChild(product));
});
